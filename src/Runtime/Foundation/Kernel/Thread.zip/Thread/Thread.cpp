﻿//***********************************************************
//! @file
//! @brief		スレッド
//! @author		Gajumaru
//***********************************************************
#include "Thread.hpp"
#include <Foundation/Algorithm/MemoryUtility.hpp>
#include "Platform/ThreadPlatform.hpp"
#include <Foundation/Memory/Device/MemoryDevice.hpp>

namespace ob
{
    namespace kernel
    {


        Thread::Thread()
            :m_pImplement(nullptr)
        {

        }

        Thread::Thread(Thread&& src)noexcept
        {
            m_pImplement = std::move(src.m_pImplement);
        }

        Thread::~Thread()
        {
            Release();
        }


        Thread& Thread::operator=(Thread&& rhs)noexcept
        {
            if (this != &rhs)
            {
                Release();
                m_pImplement = std::move(rhs.m_pImplement);
            }
            return *this;
        }


        void Thread::Release()
        {
            m_pImplement.release();
        }

        void Thread::Init(ThreadFunc pFunction, void* pArgs, const ThreadDesc& desc)
        {
            //auto memory::MemoryDevice::GetHeap();
            Release();
            m_pImplement = std::move(std::make_unique<ThreadImpl>(pFunction,pArgs,desc));
        }
        void Thread::Join()
        {

        }
        b8 Thread::IsValid()const
        {

        }
        ThreadID Thread::GetID()const
        {

        }

        ThreadID Thread::GetCurrentID()
        {

        }
        s32 Thread::GetCurrentProcessorNumder()
        {

        }
        void Thread::Sleep(u32 milliSeconds)
        {

        }
        void Thread::Switch()
        {

        }



        //-----------------------------------------------------------



    }// namespace kernel
}// namespace ob