﻿//***********************************************************
//! @file
//! @brief		スレッド
//! @author		Gajumaru
//***********************************************************
#pragma once
#include <Foundation/Base/Define.hpp>
#include <Foundation/Kernel/Type/ThreadDesc.hpp>
#include <Foundation/Kernel/Type/Platforn/KernelTypePlatform.hpp>

#include <memory>


namespace ob
{
    namespace kernel
    {
        namespace detail
        {
            class ThreadImpl;
        }
        //-----------------------------------------------------------
        

        class Thread
        {
        public:

            using ThreadFunc = void* (void*);

        public:

            //===============================================================
            // コンストラクタ / デストラクタ
            //===============================================================
            Thread();                       // コンストラクタ
            Thread(Thread&& src)noexcept;   // ムーブコンストラクタ
            ~Thread();                      // デストラクタ

            OB_DISALLOW_COPY(Thread);

            Thread& operator=(Thread&& rhs)noexcept;


            void Release();
            void Init(ThreadFunc pFunction, void* pArgs, const ThreadDesc& desc);
            void Join();
            b8 IsValid()const;
            ThreadID GetID()const;
            
            static ThreadID GetCurrentID();
            static s32 GetCurrentProcessorNumder();
            static void Sleep(u32 milliSeconds);
            static void Switch();

        private:

            void clear();

        private:

            std::unique_ptr<detail::ThreadImpl> m_pImplement;

        };






        //===============================================================
        // インライン関数
        //===============================================================

        //-----------------------------------------------------------

    }// namespace kernel
}// namespcae ob