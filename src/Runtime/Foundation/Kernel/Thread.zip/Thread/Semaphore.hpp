﻿//***********************************************************
//! @file
//! @brief		セマフォ
//! @author		Gajumaru
//***********************************************************
#pragma once
#include <Foundation/Base/Define.hpp>

namespace ob
{

    //-----------------------------------------------------------
    class SemaphoreImpl
    {

    };

    class Semaphore
    {
    public:

        Semaphore(u32 initCount, u32 maxCount);
        ~Semaphore();

        OB_DISALLOW_COPY(Semaphore);

        void Acquire();
        bool TryAquire(u32 milliSeconds);
        void release(u32 count = 1);

    private:

        SemaphoreImpl m_implement;

    };






    //===============================================================
    // インライン関数
    //===============================================================

    //-----------------------------------------------------------


}// namespcae ob