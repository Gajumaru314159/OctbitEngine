﻿//***********************************************************
//! @file
//! @brief		スレッド実装(Windows)
//! @author		Gajumaru
//***********************************************************
#pragma once
#include "ThreadImpl.hpp"
#include <process.h>

namespace ob
{
    namespace kernel
    {
        namespace detail
        {

            ThreadImpl::ThreadImpl(ThreadFunc pFunction, void* pArgs, const ThreadDesc& desc)noexcept
                :m_pFunction(pFunction)
                ,m_pArgs(pArgs)
            {
                m_handle = (HANDLE)_beginthreadex(nullptr,desc.stackSize,&ThreadImpl::EntryThread,this,CREATE_SUSPENDED,reinterpret_cast<unsigned int*>(&m_threadID));
                // assert

                int priority = THREAD_PRIORITY_NORMAL;
                switch (desc.priority)
                {
                case ob::kernel::ThreadPriority::Critical:
                    priority = THREAD_PRIORITY_TIME_CRITICAL;
                    break;
                case ob::kernel::ThreadPriority::Highest:
                    priority = THREAD_PRIORITY_HIGHEST;
                    break;
                case ob::kernel::ThreadPriority::AboveNormal:
                    priority = THREAD_PRIORITY_ABOVE_NORMAL;
                    break;
                case ob::kernel::ThreadPriority::Normal:
                    priority = THREAD_PRIORITY_NORMAL;
                    break;
                case ob::kernel::ThreadPriority::BelowNormal:
                    priority = THREAD_PRIORITY_BELOW_NORMAL;
                    break;
                case ob::kernel::ThreadPriority::Lowest:
                    priority = THREAD_PRIORITY_LOWEST;
                    break;
                }

                auto result = ::SetThreadPriority(m_handle, priority);
                // OB_CHECK_ASSERT(result,"Faild to SetThreadPriority");

#ifdef OB_DEBUG
                m_name.assign(desc.name);
#endif

                ::ResumeThread(m_handle);
            }

            ThreadImpl::~ThreadImpl()
            {
                if (m_handle != nullptr)
                {
                    ::CloseHandle(m_handle);
                }
            }



            void ThreadImpl::Join()
            {
                ::WaitForSingleObject(m_handle, INFINITE);
            }
            ThreadID ThreadImpl::GetID()const
            {
                return m_threadID;
            }


            ThreadID ThreadImpl::GetCurrentID()
            {
                return ::GetCurrentThreadId();
            }
            s32 ThreadImpl::GetCurrentProcessorNumder()
            {
                return ::GetCurrentProcessorNumber();
            }
            void ThreadImpl::Sleep(u32 milliSeconds)
            {
                return ::Sleep(milliSeconds);
            }
            void ThreadImpl::Switch()
            {
                ::SwitchToThread();
            }



            u32 WINAPI ThreadImpl::EntryThread(void* pArgs)
            {
                auto pObject = static_cast<ThreadImpl*>(pArgs);
                (*pObject->m_pFunction)(pObject->m_pArgs);
                ::_endthreadex(0);
                return 0;
            }


        }// namespace detail
    }// namespace kernel
}// namespace ob