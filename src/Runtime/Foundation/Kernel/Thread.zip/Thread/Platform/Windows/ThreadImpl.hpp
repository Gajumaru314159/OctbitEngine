﻿//***********************************************************
//! @file
//! @brief		スレッド実装(Windows)
//! @author		Gajumaru
//***********************************************************
#pragma once
#include <Windows.h>

#include <Foundation/Base/Define.hpp>
#include <Foundation/Kernel/Type/KernelType.hpp>
#include <Foundation/Kernel/Type/ThreadDesc.hpp>

namespace ob
{
    namespace kernel
    {
        namespace detail
        {
            //===============================================================
            //! @brief スレッド実装
            //===============================================================
            class ThreadImpl
            {
            public:

                ThreadImpl(ThreadFunc pFunction, void* pArgs, const ThreadDesc& desc)noexcept;
                ~ThreadImpl();



                void Join();
                ThreadID GetID()const;

            public:

                static ThreadID GetCurrentID();
                static s32 GetCurrentProcessorNumder();
                static void Sleep(u32 milliSeconds);
                static void Switch();

            private:

                static u32 WINAPI EntryThread(void* pArgs);

            private:

                HANDLE      m_handle;
                ThreadID    m_threadID;
                ThreadFunc  m_pFunction;
                void* m_pArgs;

#ifdef OB_DEBUG
                // debug_string m_name;
#endif

            };

        }// namespace detail
    }// namespace kernel
}// namespace ob