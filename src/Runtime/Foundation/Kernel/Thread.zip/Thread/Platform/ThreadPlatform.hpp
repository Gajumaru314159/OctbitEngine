﻿//***********************************************************
//! @file
//! @brief		スレッド実装
//! @author		Gajumaru
//***********************************************************
#pragma once
#include <Foundation/Base/Platform.hpp>

#if defined(OS_WINDOWS)
#include "Windows/ThreadImpl.hpp"

#elif defined(OS_ANDROID)
#include "Android/ThreadImpl.hpp"


#else
#pragma error(OS_NAME"にThreadImplの定義がありません")
#endif