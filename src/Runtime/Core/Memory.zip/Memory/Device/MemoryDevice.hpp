﻿//***********************************************************
//! @file
//! @brief		メモリデバイス
//! @author		Gajumaru
//***********************************************************
#pragma once
#include <Core/Memory/Heap/Heap.hpp>
#include <memory>
#include <array>
namespace ob
{

    //-----------------------------------------------------------

    struct HeapDesc
    {
        HeapClass   classType;  // ヒープのアルゴリズム
        Size        heapSize;   // ヒープサイズ
    };

    struct MemoryDeviceSetings
    {
        HeapDesc virtualMemory;
        HeapDesc cpuChached;
        HeapDesc gpuReadable;
        HeapDesc gpuReadWritable;

#ifdef OB_DEBUG
        HeapDesc debugVirtualMemory;
        HeapDesc debugCPUChached;
        HeapDesc debugGPUReadable;
        HeapDesc debugGPUReadWritable;
#endif
    };


    class MemoryDevice
    {
    public:

        static void Init(const MemoryDeviceSetings& settings);
        static void Release();

        static Heap& GetHeap(HeapType heapTytpe=HeapType::VirtualMemory);            // ヒープの取得
        static Heap& GetDebugHeap(HeapType heapTytpe = HeapType::VirtualMemory);     // ヒープの取得(デバッグ用)

    private:

        bool InitHeap(HeapType heapType, HeapClass classType, Size size);

    private:

        std::array<std::unique_ptr<Heap>, EnumCast(HeapType::Max)> m_heaps;

    };






    //===============================================================
    // インライン関数
    //===============================================================

    //-----------------------------------------------------------


}// namespcae ob