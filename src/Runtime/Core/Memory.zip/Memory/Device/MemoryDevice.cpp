﻿//***********************************************************
//! @file
//! @brief		ファイル説明
//! @author		Gajumaru
//***********************************************************
#include "MemoryDevice.hpp"

#include "../Heap/Heap.hpp"
#include "../Heap/OSHeap.hpp"
#include "../Heap/TLSFHeap.hpp"

namespace ob
{

    void MemoryDevice::Init(const MemoryDeviceSetings& settings)
    {

    }


    //-----------------------------------------------------------
    bool MemoryDevice::InitHeap(HeapType heapType, HeapClass classType, Size size)
    {
        const s32 index = EnumCast(heapType);
        OB_REQUIRE_RANGE(index, 0, size(m_heaps));
        auto& heap = m_heaps[index];

        OB_SAFE_DELETE(heap);

        switch (classType)
        {
        case ob::HeapClass::Invalid:
            break;
        case ob::HeapClass::System:
            heap = new OSHeap();
            break;
        case ob::HeapClass::Mimalloc:
            break;
        case ob::HeapClass::TLSF:
            heap = new TLSFHeap();
            break;
        default:
            break;
        }

        return heap != nullptr;
    }

    Heap& GetHeap(HeapType heapType)
    {
        const s32 index = static_cast<s32>(heapType);
        auto& heap = s_heaps[index];

        if (heap == nullptr)OB_ERROR("初期化されていないヒープを参照しました");

        return *heap;
    }

}// namespace ob