﻿//***********************************************************
//! @file
//! @brief		ファイル説明
//! @author		Gajumaru
//***********************************************************
#include <Core/Memory/Device/Platform/Base/MemoryDeviceImplBase.hpp>
#include <Core/Memory/Heap/include.hpp>


namespace ob
{

    //-----------------------------------------------------------
    //! @brief          コンストラクタ
    //-----------------------------------------------------------
    MemoryDeviceImplBase::MemoryDeviceImplBase()
    {

    }


    //-----------------------------------------------------------
    //! @brief          ヒープの取得
    //-----------------------------------------------------------
    Heap& MemoryDeviceImplBase::GetHeap(HeapType heapType)
    {
        const s32 index = static_cast<s32>(heapType);
        OB_REQUIRE_RANGE(index, 0, m_heaps.size());
        OB_REQUIRE(m_heaps[index], "Heap is nullptr.");
        return *m_heaps[index];
    }


    //-----------------------------------------------------------
    //! @brief              ヒープの初期化
    //! 
    //! @param heapType     初期化するヒープの種類
    //! @param classType    ヒープのアルゴリズム
    //! @param size         ヒープサイズ
    //! @param pName        ヒープ名
    //! @param p
    //! @note               ヒープ名は文字リテラルである必要があります。
    //-----------------------------------------------------------
    void MemoryDeviceImplBase::InitHeap(HeapType heapType, HeapClass classType, Size size, const Char* pName)
    {
        const s32 index = static_cast<s32>(heapType);
        OB_REQUIRE_RANGE(index, 0, m_heaps.size());

        Heap* pHeap = nullptr;

        switch (classType)
        {
        case HeapClass::System:
            pHeap = new OSHeap();
            break;
        case HeapClass::Mimalloc:
            OB_NOTIMPLEMENTED();
            break;
        case ob::HeapClass::TLSF:
            pHeap = new TLSFHeap();
            break;
        default:
            OB_NOTIMPLEMENTED();
            break;
        }
        
        if (pHeap == nullptr)OB_ERROR("ヒープの初期化に失敗しました");
        {
            std::lock_guard lg(m_mutex);
            m_heaps[index] = std::unique_ptr<Heap>(pHeap);
        }
    }

}// namespace ob