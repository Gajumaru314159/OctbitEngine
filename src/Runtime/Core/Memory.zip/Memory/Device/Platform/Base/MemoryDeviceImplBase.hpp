﻿//***********************************************************
//! @file
//! @brief		メモリデバイス実装基底クラス
//! @author		Gajumaru
//***********************************************************
#pragma once
#include <Core/Base/Fwd.hpp>
#include <Core/System/Thread/CriticalSection.hpp>
#include <Core/Memory/Heap/Heap.hpp>
#include <Core/Memory/Type/HeapType.hpp>

#include <array>
#include <memory>
#include <mutex>

namespace ob
{

    //-----------------------------------------------------------
    

    class MemoryDeviceImplBase
    {
    public:

        using HeapArray = std::array<std::unique_ptr<Heap>, static_cast<s32>(HeapType::Max)>;

    public:

        MemoryDeviceImplBase();


        Heap& GetHeap(HeapType type);

    private:

        void InitHeap(HeapType heapType, HeapClass classType,Size size, const Char* pName);

    private:

        std::mutex     m_mutex;

        HeapArray           m_heaps;


    };






    //===============================================================
    // インライン関数
    //===============================================================

    //-----------------------------------------------------------


}// namespcae ob