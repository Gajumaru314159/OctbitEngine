﻿//***********************************************************
//! @file
//! @brief		ファイル説明
//! @author		Gajumaru
//***********************************************************
#pragma once
#include <Foundation/Base/Fwd.hpp>
#include <Foundation/Template/type_traits.hpp>
#include <Foundation/Template/atomic.hpp>
#include <Foundation/Log/LogMacro.hpp>
namespace ob {

    //-----------------------------------------------------------

    class IRefObject {
    public:
        virtual ~IRefObject() {}
        virtual void Finalize()=0;
        virtual void AddRef()const noexcept = 0;
        virtual void Release()const noexcept = 0;
        virtual s32 GetRefCount()const noexcept = 0;
    };

    //-----------------------------------------------------------
    //! @brief      参照カウント・オブジェクト
    //! @detais     カウントはスレッド・セーフです。
    //-----------------------------------------------------------
    class RefObject :public Noncopyable,public IRefObject {
    public:
        RefObject() {
            m_refCount.store(0, memory_order::memory_order_release);
        }

        ~RefObject() {
            OB_REQUIRE_EX(m_refCount==0,"Memory", "オブジェクトの参照カウンタが不正です。");
        }

        void Finalize()override{}

        void AddRef()const noexcept override {
            m_refCount.fetch_add(1);
        }

        void Release()const noexcept override {
            if (0 < m_refCount.fetch_sub(1))return;
            delete this;
        }

        s32 GetRefCount()const noexcept override {
            return m_refCount;
        }

    private:
        
        mutable atomic<s32> m_refCount;

    };


    //-----------------------------------------------------------
    //! @brief 参照カウント・オブジェクト
    //-----------------------------------------------------------
    template<class T>
    class Ref {
        static_assert(is_base_of_v<IRefObject, T>, "Refで管理するオブジェクトはIRefObjectを実装している必要があります。");
    public:

        constexpr Ref() noexcept;                           // 参照を持たない空の Ref を構築する
        Ref(T* ptr, bool addRef=true);                      // 生ポインタの所有権を受け取る

        Ref(const Ref& ref) noexcept;                       // コピーコンストラクタ
        Ref(Ref&& ref) noexcept;                            // ムーブコンストラクタ

        ~Ref();                                             // デストラクタ


        Ref& operator=(T* ref) noexcept;                    // コピーコンストラクタ
        Ref& operator=(const Ref& ref) noexcept;            // コピーコンストラクタ
        Ref& operator=(Ref&& ref) noexcept;                 // ムーブコンストラクタ

        /** ポインタを間接参照します。 */
        T& operator*() const;                               // ポインタを間接参照する
        T* operator->() const;                              // ポインタを通してオブジェクトのメンバにアクセスする
        explicit operator bool() const noexcept;            // 有効なポインタを保持しているか

        s32 GetRefCount()const noexcept;
        bool IsValid()const noexcept;

        void Release();                                     // 保持するオブジェクトのポインタを解放する
        void Swap(Ref<T>& other);                           // 2つの Ref オブジェクトを入れ替える

        T* Get() const;                                     // 保持しているオブジェクトのポインタを取得する

    public:

        static const Ref<T> Null;                           //!< Null値

    protected:

        RefObject* m_ptr;

    };

    template<class T>
    const Ref<T> Ref<T>::Null;






    //===============================================================
    // インライン関数
    //===============================================================

    //-----------------------------------------------------------
    //! @brief コンストラクタ
    //-----------------------------------------------------------
    template<class T>
    constexpr Ref<T>::Ref()noexcept
        : m_ptr(nullptr) {
    }

    template<class T>
    Ref<T>::Ref(T* ptr, bool addRef)
    {
        m_ptr = ptr;
        if (ptr&&addRef) {
            ptr->AddRef();
        }
    }

    template<class T>
    Ref<T>::Ref(const Ref& ref)noexcept
    {
        m_ptr = ref.m_ptr;
        if (ptr && addRef) {
            ptr->AddRef();
        }
    }

    template<class T>
    Ref<T>::Ref(Ref&& ref) noexcept {
        m_ptr = ref.m_ptr;
        ref.m_ptr = nullptr;
    }

    template<class T>
    Ref<T>::~Ref() {
        if (m_ptr) {
            m_ptr->Release();
        }
    }

    template<class T>
    Ref<T>& Ref<T>::operator=(T* ptr) noexcept {
        if (ptr) {
            ptr->AddRef();
        }
        if (m_ptr) {
            m_ptr->Release();
        }
        m_ptr = ptr;
        return *this;
    }

    template<class T>
    Ref<T>& Ref<T>::operator=(const Ref<T>& ref) noexcept {
		return *this=ref.m_ptr;
    }

    template<class T>
    Ref<T>& Ref<T>::operator=(Ref&& ref) noexcept {
        if (this != &ref) {
            if (m_ptr) {
                m_ptr->Release();
            }
            m_ptr = ref.m_ptr;
            ref.m_ptr = nullptr;
        }
        return *this;
    }

    template<class T>
    T& Ref<T>::operator*() const{
        return *m_ptr
    }

    template<class T>
    T* Ref<T>::operator->() const{
        return m_ptr;
    }

    template<class T>
    Ref<T>::operator bool() const noexcept {
        return m_ptr != nullptr;
    }

    template<class T>
    s32 Ref<T>::GetRefCount()const noexcept {
        if (m_ptr)return m_ptr->GetRefCount();
        return 0;
    }

    template<class T>
    bool Ref<T>::IsValid()const noexcept {
        return operator bool();
    }

    template<class T>
    void Ref<T>::Release() {
        *this = nullptr;
    }

    template<class T>
    void Ref<T>::Swap(Ref<T>& other) {
        ob::swap(m_pttr, other.m_ptr);
    }

    template<class T>
    T* Ref<T>::Get() const {
        return m_ptr;
    }


    //===============================================================
    // 比較演算子
    //===============================================================
    
    //-----------------------------------------------------------
    //@brief Ref 同士の等価演算子
    //-----------------------------------------------------------
    template<class T, class U>
    bool operator==(const Ref<T>& lhs, const Ref<U>& rhs) noexcept {
        return (lhs.Get() == rhs.Get());
    }

    //-----------------------------------------------------------
    //@brief Ref 同士の比較
    //-----------------------------------------------------------
    template<class T>
    bool operator==(const Ref<T>& lhs, std::nullptr_t) noexcept {
        return (lhs.Get() == nullptr);
    }

    //-----------------------------------------------------------
    //@brief Ref 同士の比較
    //-----------------------------------------------------------
    template<class T>
    bool operator==(std::nullptr_t, const Ref<T>& rhs) noexcept {
        return (nullptr == rhs.Get());
    }

    //-----------------------------------------------------------
    //@brief Ref 同士の否等価演算子
    //-----------------------------------------------------------
    template<class T, class U>
    bool operator!=(const Ref<T>& lhs, const Ref<U>& rhs) noexcept {
        return !(lhs == rhs);
    }

    //-----------------------------------------------------------
    //@brief Ref と nullptr の否等価演算子
    //-----------------------------------------------------------
    template<class T>
    bool operator!=(const Ref<T>& lhs, std::nullptr_t) noexcept {
        return !(lhs == rhs);
    }

    //-----------------------------------------------------------
    //@brief nullptr と Ref 同士の否等価演算子
    //-----------------------------------------------------------
    template<class T>
    bool operator!=(std::nullptr_t, const Ref<T>& rhs) noexcept {
        return !(lhs == rhs);
    }

    //-----------------------------------------------------------
    // @brief       Refの構築
    //-----------------------------------------------------------
    template<class T, class... TArgs>
    inline Ref<T> MakeRef(TArgs&&... args) {
        return Ref<T>(new T(std::forward<TArgs>(args)...), false);
    }


}// namespcae ob