﻿//***********************************************************
//! @file
//! @brief		ファイル説明
//! @author		Gajumaru
//***********************************************************
#pragma once

namespace ob
{
    //-----------------------------------------------------------
    // ヒープタイプ
    //-----------------------------------------------------------
    enum class HeapType
    {
        VirtualMemory = 0,            //!< 仮想メモリ
        CPUCached,              //!< CPU側キャッシュ

        GPUReadable,            //!< GPU読み込み
        GPUReadWritable,         //!< GPU読み書き

        Max
    };


    enum class HeapClass
    {
        Invalid,    // 不正

        System,     // システムのnew/deleteによるメモリ確保
        Mimalloc,   // mimalloc
        TLSF,       // Two-Level Segregate Fit
    };
}// namespcae ob