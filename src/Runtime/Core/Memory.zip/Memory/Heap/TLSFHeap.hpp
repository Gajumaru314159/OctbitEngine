﻿//***********************************************************
//! @file
//! @brief		ファイル説明
//! @author		Gajumaru
//***********************************************************
#pragma once
#include "Heap.hpp"

namespace ob
{

    //-----------------------------------------------------------
    

    class TLSFHeap:public Heap
    {
    public:


    private:

        virtual void Clear() override;

        virtual void Destroy() override;

        virtual Size GetHeapSize() const override;

        virtual Size GetFreeHeapSize() const override;

        virtual bool IsValid() const override;

        virtual void* AllocateImpl(Size size) override;

        virtual void DeallocateImpl(void* ptr) override;

    };






    //===============================================================
    // インライン関数
    //===============================================================

    //-----------------------------------------------------------


}// namespcae ob