﻿//***********************************************************
//! @file
//! @brief		ファイル説明
//! @author		Gajumaru
//***********************************************************
#pragma once

#include "Heap.hpp"

namespace ob
{

    //-----------------------------------------------------------
    

    class SystemHeap :public IHeap
    {
    public:

        // IHeap を介して継承されました
        virtual void Release() override;
        virtual void* Allocate(Size size, Size alignment = DEFAULT_ALIGNMENT) override;
        virtual void Deallocate(void* ptr) override;
        virtual Size GetHeapSize() const override;
        virtual Size GetFreeHeapSize() const override;
        virtual bool IsValid() const override;
    };






    //===============================================================
    // インライン関数
    //===============================================================

    //-----------------------------------------------------------


}// namespcae ob