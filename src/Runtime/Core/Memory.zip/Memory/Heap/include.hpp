﻿#pragma once

#include "Heap.hpp"
#include "OSHeap.hpp"
#include "StackHeap.hpp"
#include "TLSFHeap.hpp"