﻿//***********************************************************
//! @file
//! @brief		ヒープ基底クラス
//! @author		Gajumaru
//***********************************************************
#pragma once
#include <Foundation/Define/Define.hpp>
#include <Foundation/Kernel/CriticalSection/CriticalSection.hpp>
#include "../Type/HeapType.hpp"


namespace ob
{

    //! @brief システムのデフォルトアライメント
#define DEFAULT_ALIGNMENT __STDCPP_DEFAULT_NEW_ALIGNMENT__

    class HeapInstance;

    class IHeap
    {
    public:
        //===============================================================
        //  コンストラクタ / デストラクタ
        //===============================================================
        virtual ~IHeap() {};


        virtual void* Malloc(Size size, u32 alignment = DEFAULT_ALIGNMENT) = 0;
        virtual void* Realloc(void* pBuffer, Size size,u32 alignment= DEFAULT_ALIGNMENT) = 0;
        virtual void Free(void* pBuffer)=0;
        virtual Size GetQuantizeSize(Size size, u32 alignment);

        virtual void	Release() = 0;                                      // 内部アロケート情報のクリア


        //===============================================================
        //  メモリ確保 /解放
        //===============================================================
        virtual void* Allocate(Size size, Size alignment = DEFAULT_ALIGNMENT)=0;      // メモリ確保
        virtual void Deallocate(void* ptr)=0;                                         // メモリ開放

        template<typename T, typename... Args>
        T* Allocate(Args&&... args)
        {
            return new(Allocate(sizeof(T)))(std::move(args...));
        }




        virtual Size	GetHeapSize()		const = 0;                      // アロケータのヒープサイズを取得
        virtual Size	GetFreeHeapSize()	const = 0;                      // アロケータの使用可能なヒープサイズを取得
        virtual bool	IsValid()const = 0;                                 // 利用可能な状態かどうか

    public:

        static void Free(void* pBuffer);

    private:

        HeapInstance* m_instance;

    };


    //-----------------------------------------------------------
    //! @brief      ヒープ上に実際に書く越されるメモリサイズを取得
    //! 
    //! @details    一部のメモリアロケータでは、断片化を解消するためにsize以上のメモリを確保します。
    //!             この関数を使用すると実際に割り当てられたサイズを取得できます。
    //-----------------------------------------------------------
    inline Size IHeap::GetQuantizeSize(Size size, u32 alignment)
    {
        return size;
    }
    


    //-----------------------------------------------------------
    //! @brief メモリアロケータの基底クラス
    //-----------------------------------------------------------
    class OB_API Heap
    {
    public:

        using HeapPtr = Heap*;

    protected:

        //-----------------------------------------------------------
        //! @brief アロケートされたメモリの情報
        //-----------------------------------------------------------
        struct Header
        {
            Heap* heap=nullptr;	        //!< 確保元のメモリアロケータ
            Size size=0;				//!< 割り当てサイズ
            Size adjustment=0;			//!< アラインメント調整量
            u32 signature=0;		    //!< シグネチャ(メモリ破壊チェック用)

            void Set(Heap* heap, Size size, Size adjustment);   //!< 構造体のセット

        };

    public:

        //===============================================================
        //  コンストラクタ / デストラクタ
        //===============================================================
        Heap();				                                                //!< コンストラクタ
        virtual	~Heap() {}				                                    //!< デストラクタ




        //===============================================================
        //  メモリ確保 /解放
        //===============================================================
        void* Allocate(Size size, Size alignment = DEFAULT_ALIGNMENT);      // メモリ確保
        template<typename T,typename... Args>
        T* Allocate(Args&&... args);                                                   // メモリ確保
        void Deallocate(void* ptr);                                         // メモリ開放

        static void Free(void* pBuffer);

        //===============================================================
        //  ゲッター / セッター
        //===============================================================
        void            SetName(const Char* pName);                         // 名前を設定
        const Char* GetName()const;                      	                // 名前を取得

        HeapPtr         GetParentHeap()const;                               // 確保元の親ヒープ取得

        //===============================================================
        //  仮想関数
        //===============================================================
        virtual void	Clear() = 0;                                        // 内部アロケート情報のクリア
        virtual void	Destroy() = 0;                                      // アロケータの破棄

        virtual Size	GetHeapSize()		const = 0;                      // アロケータのヒープサイズを取得
        virtual Size	GetFreeHeapSize()	const = 0;                      // アロケータの使用可能なヒープサイズを取得
        virtual bool	IsValid()const = 0;                                 // 利用可能な状態かどうか

    protected:

        virtual void* AllocateImpl(Size size) = 0;                          // 内部メモリ確保
        virtual void	DeallocateImpl(void* ptr) = 0;                      // 内部メモリ開放

    private:

        void SetSignature(void* ptr);                                       // チェック用署名の書き込み
        bool CheckSignature(void* ptr)const;                                 // 署名が正しいかチェック

    protected:

        CriticalSection	m_criticalSection;      //!< クリティカルセクション
        Heap* m_parentHeap;                     //!< 確保元の親ヒープ
        const Char* m_pName;             //!< ヒープ名のポインタ

        OB_DISALLOW_COPY(Heap);
    };






    //===============================================================
    // インライン関数
    //===============================================================

    //-----------------------------------------------------------
    // @brief デフォルトコンストラクタ
    //-----------------------------------------------------------
    inline Heap::Heap()
        : m_criticalSection()
        , m_parentHeap(nullptr)
        , m_pName(nullptr)
    {}


    //-----------------------------------------------------------
    //! @brief 名前を設定
    //-----------------------------------------------------------
    inline void  Heap::SetName(const Char* pName) {
        m_pName = pName;
    }
    //-----------------------------------------------------------
    //! @brief 名前を取得
    //-----------------------------------------------------------
    inline const Char* Heap::GetName()const {
        return m_pName;
    }


    //-----------------------------------------------------------
    //! @brief 確保元の親ヒープ取得
    //-----------------------------------------------------------
    inline Heap* Heap::GetParentHeap()const {
        return m_parentHeap;
    }

    template<typename T, typename... Args>
    T* Heap::Allocate(Args&&... args)
    {
        return new(Allocate(sizeof(T),std::alignment_of(T))(std::move(args...))
    }


    //-----------------------------------------------------------
    //! @brief          内部メモリ確保
    //! 
    //! @param size     確保するメモリ容量
    //! @return         割り当てられたメモリのポインタ
    //-----------------------------------------------------------


    //-----------------------------------------------------------
    //! @brief          内部メモリ開放
    //! 
    //! @param ptr      解放するポインタ
    //-----------------------------------------------------------

}// namespace ob