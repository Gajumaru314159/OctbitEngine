﻿#include "TLSFHeap.hpp"
//***********************************************************
//! @file
//! @brief		ファイル説明
//! @author		Gajumaru
//***********************************************************

namespace ob
{

	//-----------------------------------------------------------

	void TLSFHeap::Clear()
	{
		OB_NOTIMPLEMENTED();
	}

	void TLSFHeap::Destroy()
	{
		OB_NOTIMPLEMENTED();
	}

	Size TLSFHeap::GetHeapSize() const
	{
		OB_NOTIMPLEMENTED();
		return Size();
	}

	Size TLSFHeap::GetFreeHeapSize() const
	{
		OB_NOTIMPLEMENTED();
		return Size();
	}

	bool TLSFHeap::IsValid() const
	{
		return false;
	}

	void* TLSFHeap::AllocateImpl(Size size)
	{
		return nullptr;
	}

	void TLSFHeap::DeallocateImpl(void* ptr)
	{
		OB_NOTIMPLEMENTED();
	}

}// namespace ob