﻿//***********************************************************
//! @file
//! @brief		ファイル説明
//! @author		Gajumaru
//***********************************************************
#include "SystemHeap.hpp"
#include <new>
#include <cassert>

namespace ob
{

	//-----------------------------------------------------------


	void SystemHeap::Release()
	{
	}

	void* SystemHeap::Allocate(Size size, Size alignment)
	{
		return new(std::align_val_t{ alignment }) char[size];
	}

	void SystemHeap::Deallocate(void* ptr)
	{
		assert(ptr!=nullptr);
		delete ptr;
	}

	Size SystemHeap::GetHeapSize() const
	{
		return Size()-1;
	}

	Size SystemHeap::GetFreeHeapSize() const
	{
		return Size()-1;
	}

	bool SystemHeap::IsValid() const
	{
		return false;
	}

}// namespace ob